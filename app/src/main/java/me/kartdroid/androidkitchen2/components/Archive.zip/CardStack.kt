package me.kartdroid.androidkitchen2.components

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun <T> CardStack(
    items: List<T>,
    cardContent: @Composable (T) -> Unit,
    modifier: Modifier = Modifier,
    visibleCards: Int = 3,
    cardPadding: Float = 16f,
    scaleRatio: Float = 0.05f,
    swipeThreshold: Float = 250f,
    animationSpec: AnimationSpec<Float> = SpringSpec(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessMedium
    ),
    onSwipe: (Int) -> Unit = {}
) {
    if (items.isEmpty()) return

    var currentIndex by remember { mutableIntStateOf(0) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var isDragging by remember { mutableStateOf(false) }

    val density = LocalDensity.current
    val cardPaddingPx = with(density) { cardPadding.dp.toPx() }

    Box(modifier = modifier.fillMaxWidth()) {
        // Render visible cards from back to front
        items.take(visibleCards).forEachIndexed { index, item ->
            if (currentIndex + index < items.size) {
                val itemIndex = currentIndex + index
                val cardItem = items[itemIndex]

                val offsetPercentage = offsetX / swipeThreshold
                val scale = 1f - (index * scaleRatio)
                val yOffset = index * cardPaddingPx

                // Calculate animations
                val cardOffsetX = when (index) {
                    0 -> offsetX
                    else -> 0f
                }

                val cardAlpha by animateFloatAsState(
                    targetValue = if (index == 0 && abs(offsetPercentage) > 0.5f && isDragging) {
                        1f - (abs(offsetPercentage) - 0.5f) * 2f
                    } else {
                        1f
                    },
                    animationSpec = animationSpec,
                    label = "cardAlpha"
                )

                val cardScale by animateFloatAsState(
                    targetValue = scale,
                    animationSpec = animationSpec,
                    label = "cardScale"
                )

                Box(
                    modifier = Modifier
                        .zIndex(visibleCards.toFloat() - index)
                        .fillMaxWidth()
                        .offset { IntOffset(cardOffsetX.roundToInt(), yOffset.roundToInt()) }
                        .alpha(cardAlpha)
                        .scale(cardScale)
                        .padding(horizontal = 16.dp)
                        .pointerInput(itemIndex) {
                            if (index == 0) {
                                detectHorizontalDragGestures(
                                    onDragStart = { isDragging = true },
                                    onDragEnd = {
                                        isDragging = false
                                        if (abs(offsetX) > swipeThreshold) {
                                            // Determine swipe direction
                                            val direction = if (offsetX > 0) 1 else -1

                                            // Update current index based on swipe direction
                                            val nextIndex = if (direction < 0) {
                                                // Swiped left, go to next card
                                                (currentIndex + 1).coerceAtMost(items.size - 1)
                                            } else {
                                                // Swiped right, go to previous card
                                                (currentIndex - 1).coerceAtLeast(0)
                                            }

                                            currentIndex = nextIndex
                                            onSwipe(currentIndex)
                                        }
                                        offsetX = 0f
                                    },
                                    onDragCancel = {
                                        isDragging = false
                                        offsetX = 0f
                                    },
                                    onHorizontalDrag = { _, dragAmount ->
                                        offsetX += dragAmount
                                    }
                                )
                            }
                        }
                ) {
                    cardContent(cardItem)
                }
            }
        }
    }
}



