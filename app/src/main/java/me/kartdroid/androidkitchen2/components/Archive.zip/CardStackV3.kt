package me.kartdroid.androidkitchen2.components
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.SpringSpec
import androidx.compose.animation.core.VectorConverter
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt

/**
 * Configuration for the iMessage CardStack
 */
data class IMessageCardStackConfig(
    val maxVisibleCards: Int = 3,
    val initialCardScale: Float = 0.90f,
    val initialCardYOffset: Float = 25f,
    val initialCardOpacity: Float = 0.7f,
    val swipeThreshold: Float = 0.4f,
    val perspectiveMultiplier: Float = 0.4f,
    val maxRotationDegrees: Float = 20f,
    val maxScaleEffect: Float = 0.05f,
    val springStiffness: Float = Spring.StiffnessMedium,
    val springDampingRatio: Float = Spring.DampingRatioMediumBouncy
)

/**
 * Advanced iMessage-style CardStack for Jetpack Compose
 *
 * @param cards List of composable content to display as cards
 * @param onSwipe Callback when a card is swiped in a direction
 * @param config Configuration for the CardStack
 * @param modifier Modifier for the CardStack container
 */
@Composable
fun IMessageCardStack(
    cards: List<CardData>,
    onSwipe: (index: Int, direction: SwipeDirection) -> Unit = { _, _ -> },
    config: IMessageCardStackConfig = IMessageCardStackConfig(),
    cardContent: @Composable (CardData) -> Unit,
    modifier: Modifier = Modifier
) {
    if (cards.isEmpty()) return

    var topCardIndex by remember { mutableStateOf(0) }
    val visibleCards = cards.subList(topCardIndex, minOf(topCardIndex + config.maxVisibleCards, cards.size))
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    // Remember the animation specs
    val springSpec = remember {
        SpringSpec<Offset>(
            dampingRatio = config.springDampingRatio,
            stiffness = config.springStiffness
        )
    }

    // Track if the top card is being dragged
    var isTopCardDragging by remember { mutableStateOf(false) }

    // Track the drag distance of the top card for background cards animation
    var topCardDragAmount by remember { mutableStateOf(Offset.Zero) }

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val maxWidth = constraints.maxWidth.toFloat()
        val maxHeight = constraints.maxHeight.toFloat()
        val swipeThresholdWidth = maxWidth * config.swipeThreshold
        val swipeThresholdHeight = maxHeight * config.swipeThreshold

        // Render visible cards in reverse order (bottom to top)
        visibleCards.asReversed().forEachIndexed { reversedIndex, content ->
            val actualIndex = visibleCards.size - 1 - reversedIndex
            val isTopCard = actualIndex == 0

            if (isTopCard) {
                // Top card with interactive dragging
                InteractiveDraggableCard(
                    onSwiped = { direction ->
                        if (topCardIndex < cards.size) {
                            onSwipe(topCardIndex, direction)
                            topCardIndex++
                        }
                    },
                    onDragUpdate = { dragAmount ->
                        // Update drag amount for background cards animation
                        topCardDragAmount = dragAmount
                        isTopCardDragging = true
                    },
                    onDragEnd = {
                        isTopCardDragging = false
                        topCardDragAmount = Offset.Zero
                    },
                    swipeThresholdWidth = swipeThresholdWidth,
                    swipeThresholdHeight = swipeThresholdHeight,
                    maxRotationDegrees = config.maxRotationDegrees,
                    maxScaleEffect = config.maxScaleEffect,
                    perspectiveMultiplier = config.perspectiveMultiplier,
                    springSpec = springSpec
                ) {
                    cardContent(content)
                }
            } else {
                // Calculate responsive background card properties
                val cardDepth = actualIndex.toFloat()

                // Default values (when top card is not being dragged)
                val baseScale = config.initialCardScale.pow(cardDepth)
                val baseYOffset = config.initialCardYOffset * cardDepth
                val baseOpacity = config.initialCardOpacity.pow(cardDepth)

                // Calculate dynamic properties based on top card drag
                val dragPercentage = if (isTopCardDragging) {
                    val dragDistance = max(abs(topCardDragAmount.x) / swipeThresholdWidth,
                        abs(topCardDragAmount.y) / swipeThresholdHeight)
                    min(dragDistance, 1f)
                } else 0f

                // Spring-forward effect - background cards come forward as top card is dragged
                val dynamicScale = baseScale + (dragPercentage * 0.05f * (1f / (cardDepth + 1f)))
                val dynamicYOffset = baseYOffset - (dragPercentage * 10f * (1f / (cardDepth + 1f)))
                val dynamicOpacity = baseOpacity + (dragPercentage * 0.1f * (1f / (cardDepth + 1f)))
                val density = LocalDensity.current
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = with(density) { dynamicYOffset.toDp()})
                        .graphicsLayer {
                            scaleX = dynamicScale
                            scaleY = dynamicScale
                            alpha = dynamicOpacity
                        }
                ) {
                    cardContent(content)
                }
            }
        }
    }
}

@Composable
private fun InteractiveDraggableCard(
    onSwiped: (SwipeDirection) -> Unit,
    onDragUpdate: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    swipeThresholdWidth: Float,
    swipeThresholdHeight: Float,
    maxRotationDegrees: Float,
    maxScaleEffect: Float,
    perspectiveMultiplier: Float,
    springSpec: SpringSpec<Offset>,
    content: @Composable () -> Unit
) {
    val offset = remember { Animatable(Offset.Zero, Offset.VectorConverter) }
    val coroutineScope = rememberCoroutineScope()
    val density = LocalDensity.current

    // Track primary drag direction
    var primaryDragDirection by remember { mutableStateOf<SwipeDirection?>(null) }

    // Reset animation when not dragging
    LaunchedEffect(offset.value) {
        // Update the parent with current drag amount
        onDragUpdate(offset.value)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .offset {
                IntOffset(
                    offset.value.x.roundToInt(),
                    offset.value.y.roundToInt()
                )
            }
            .graphicsLayer {
                // Apply 3D perspective transformations
                // The perspective effect is stronger as the card is dragged further
                val dragPercentageX = (offset.value.x / swipeThresholdWidth).coerceIn(-1f, 1f)
                val dragPercentageY = (offset.value.y / swipeThresholdHeight).coerceIn(-1f, 1f)

                // Determine which axis has the larger drag percentage
                val isHorizontalDragDominant = abs(dragPercentageX) > abs(dragPercentageY)

                // Apply rotations based on primary drag direction
                if (isHorizontalDragDominant) {
                    // Horizontal drag - rotate around Y axis
                    rotationY = -dragPercentageX * maxRotationDegrees

                    // Add slight tilt for more natural feel
                    rotationZ = dragPercentageX * (maxRotationDegrees / 3f)
                } else {
                    // Vertical drag - rotate around X axis
                    rotationX = dragPercentageY * maxRotationDegrees
                }

                // Apply perspective and scaling
                cameraDistance = 8 * density.density * (1 - perspectiveMultiplier * max(abs(dragPercentageX), abs(dragPercentageY)))

                // Scale effect - card appears slightly smaller as it's dragged away
                val scaleFactor = 1f - (max(abs(dragPercentageX), abs(dragPercentageY)) * maxScaleEffect)
                scaleX = scaleFactor
                scaleY = scaleFactor
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { _ ->
                        // Reset primary direction
                        primaryDragDirection = null
                    },
                    onDragEnd = {
                        coroutineScope.launch {
                            // Determine if we should swipe away or return to center
                            val currentOffset = offset.value
                            when {
                                currentOffset.x > swipeThresholdWidth -> {
                                    // Swipe right
                                    offset.animateTo(Offset(size.width * 1.5f, currentOffset.y), springSpec)
                                    onSwiped(SwipeDirection.RIGHT)
                                }
                                currentOffset.x < -swipeThresholdWidth -> {
                                    // Swipe left
                                    offset.animateTo(Offset(-size.width * 1.5f, currentOffset.y), springSpec)
                                    onSwiped(SwipeDirection.LEFT)
                                }
                                currentOffset.y > swipeThresholdHeight -> {
                                    // Swipe down
                                    offset.animateTo(Offset(currentOffset.x, size.height * 1.5f), springSpec)
                                    onSwiped(SwipeDirection.DOWN)
                                }
                                currentOffset.y < -swipeThresholdHeight -> {
                                    // Swipe up
                                    offset.animateTo(Offset(currentOffset.x, -size.height * 1.5f), springSpec)
                                    onSwiped(SwipeDirection.UP)
                                }
                                else -> {
                                    // Return to center with spring animation
                                    offset.animateTo(Offset.Zero, springSpec)
                                }
                            }
                            onDragEnd()
                        }
                    },
                    onDragCancel = {
                        coroutineScope.launch {
                            // Return to center with spring animation
                            offset.animateTo(Offset.Zero, springSpec)
                            onDragEnd()
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()

                        // Update offset with current drag
                        coroutineScope.launch {
                            val newOffset = offset.value + dragAmount
                            offset.snapTo(newOffset)

                            // Determine primary drag direction if not set
                            if (primaryDragDirection == null) {
                                // Wait until we have a significant drag to determine direction
                                if (abs(offset.value.x) > 40 || abs(offset.value.y) > 40) {
                                    primaryDragDirection = when {
                                        abs(offset.value.x) > abs(offset.value.y) -> {
                                            if (offset.value.x > 0) SwipeDirection.RIGHT else SwipeDirection.LEFT
                                        }
                                        else -> {
                                            if (offset.value.y > 0) SwipeDirection.DOWN else SwipeDirection.UP
                                        }
                                    }
                                }
                            }
                        }
                    }
                )
            }
    ) {
        content()
    }
}

// Helper extension function for power operations on Float
private fun Float.pow(exponent: Float): Float {
    return this.toDouble().pow(exponent.toDouble()).toFloat()
}


@Preview
@Composable
fun IMessageCardStackExample() {
    var cards by remember { mutableStateOf(generateSampleCards()) }
    var lastSwipedDirection by remember { mutableStateOf<SwipeDirection?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Title
        Text(
            text = "iMessage CardStack",
            style = MaterialTheme.typography.h5,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(16.dp)
        )

        // Card stack container
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            IMessageCardStack(
                cards = cards,
                onSwipe = { index, direction ->
                    lastSwipedDirection = direction
                    // Remove the card that was swiped
                    cards = cards.filterIndexed { i, _ -> i != 0 }
                    // Add a new card at the end if needed
                    if (cards.size < 5) {
                        cards = cards + listOf(
                            CardData(
                                title = "New Card ${(Math.random() * 100).toInt()}",
                                gradient = getRandomGradient()
                            )
                        )
                    }
                },
                config = IMessageCardStackConfig(
                    maxVisibleCards = 5,
                    initialCardScale = 0.80f,
                    initialCardYOffset = 59f,
                    maxRotationDegrees = 50f,
                    perspectiveMultiplier = 0.75f,
                    springDampingRatio = Spring.DampingRatioMediumBouncy
                ),
                modifier = Modifier.fillMaxSize(),
                cardContent = {
                    FancyCard(
                        title = it.title,
                        gradient = it.gradient
                    )
                }
            )

            // Display last swipe direction
            lastSwipedDirection?.let {
                Text(
                    text = "Swiped $it",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .background(
                            color = Color(0xFF333333),
                            shape = RoundedCornerShape(16.dp)
                        )
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        }

        // Reset button
        Button(
            onClick = {
                cards = generateSampleCards()
                lastSwipedDirection = null
            },
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(bottom = 16.dp)
        ) {
            Text("Reset Cards")
        }
    }
}

@Composable
fun FancyCard(title: String, gradient: Brush) {
    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(24.dp),
        elevation = 8.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(gradient),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = title,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )

                Text(
                    text = "Swipe in any direction",
                    fontSize = 16.sp,
                    color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}

private fun generateSampleCards(): List<CardData> {
    val gradients = listOf(
        // Blue to Purple
        Brush.linearGradient(listOf(Color(0xFF2196F3), Color(0xFF9C27B0))),
        // Red to Orange
        Brush.linearGradient(listOf(Color(0xFFF44336), Color(0xFFFF9800))),
        // Green to Teal
        Brush.linearGradient(listOf(Color(0xFF4CAF50), Color(0xFF009688))),
        // Purple to Pink
        Brush.linearGradient(listOf(Color(0xFF9C27B0), Color(0xFFE91E63))),
        // Orange to Yellow
        Brush.linearGradient(listOf(Color(0xFFFF9800), Color(0xFFFFEB3B)))
    )

    return List(5) { index ->
        CardData(
            title = "Card ${index + 1}",
            gradient = gradients[index % gradients.size]
        )
    }
}

private fun getRandomGradient(): Brush {
    val color1 = Color(
        red = (Math.random() * 0.7f + 0.3f).toFloat(),
        green = (Math.random() * 0.7f + 0.3f).toFloat(),
        blue = (Math.random() * 0.7f + 0.3f).toFloat()
    )

    val color2 = Color(
        red = (Math.random() * 0.7f + 0.3f).toFloat(),
        green = (Math.random() * 0.7f + 0.3f).toFloat(),
        blue = (Math.random() * 0.7f + 0.3f).toFloat()
    )

    return Brush.linearGradient(listOf(color1, color2))
}

@Preview(showBackground = true)
@Composable
fun IMessageCardStackPreview() {
    MaterialTheme {
        IMessageCardStackExample()
    }
}