package me.kartdroid.androidkitchen2.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import me.kartdroid.androidkitchen2.ui.theme.AndroidKitchen2Theme

@Preview
@Composable
fun CardStackExample() {
    val items = listOf(
        CardData("Card 1", Color(0xFF4CAF50)),
        CardData("Card 2", Color(0xFF2196F3)),
        CardData("Card 3", Color(0xFFF44336)),
        CardData("Card 4", Color(0xFFFF9800)),
        CardData("Card 5", Color(0xFF9C27B0)),
        CardData("Card 6", Color(0xFF3F51B5)),
        CardData("Card 7", Color(0xFF009688)),
        CardData("Card 8", Color(0xFF8BC34A)),
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF5F5F5))
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        CardStack(
            items = items,
            cardContent = { item ->
                CardItem(item)
            },
            visibleCards = 4,
            cardPadding = 24f,
            scaleRatio = 0.05f,
            swipeThreshold = 100f,
            onSwipe = { index ->
                // Handle swipe - you can trigger animations or update data
                println("Swiped to card at index: $index")
            }
        )
    }
}

@Composable
fun CardItem(cardData: CardData) {
    AndroidKitchen2Theme {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp),
            shape = RoundedCornerShape(16.dp),
            elevation = 8.dp,
            backgroundColor = cardData.color,
            contentColor = Color.Black,
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Surface {
                    Text(
                        text = cardData.title,
                        style = MaterialTheme.typography.body1,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }
        }
    }
}

data class CardData(
    val title: String,
    val color: Color = Color.Unspecified,
    val gradient: Brush = Brush.linearGradient(
        colors = listOf(Color.Red, Color.Blue, Color.Green),
        start = androidx.compose.ui.geometry.Offset(0f, 0f),
        end = androidx.compose.ui.geometry.Offset(100f, 100f)
    )
)