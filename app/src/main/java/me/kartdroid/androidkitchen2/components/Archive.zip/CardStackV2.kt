package me.kartdroid.androidkitchen2.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.IntOffset
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Direction in which a card can be swiped
 */
//enum class SwipeDirection {
//    LEFT, RIGHT, UP, DOWN
//}

/**
 * Configuration for the CardStack
 */
data class CardStackConfig(
    val maxVisibleCards: Int = 3,
    val cardScale: Float = 0.92f,
    val cardYOffset: Float = 15f,
    val swipeThreshold: Float = 0.4f,
    val rotationFactor: Float = 0.1f,
    val animationSpec: androidx.compose.animation.core.AnimationSpec<Offset> = spring(
        stiffness = Spring.StiffnessMediumLow
    )
)

/**
 * A Jetpack Compose version of the CardStack component
 *
 * @param cards List of composable content to display as cards
 * @param onSwipe Callback when a card is swiped in a direction
 * @param config Configuration for the CardStack
 * @param modifier Modifier for the CardStack container
 */
@Composable
fun CardStack(
    cards: List<CardData>,
    onSwipe: (index: Int, direction: SwipeDirection) -> Unit = { _, _ -> },
    config: CardStackConfig = CardStackConfig(),
    cardContent: @Composable (CardData) -> Unit,
    modifier: Modifier = Modifier
) {
    if (cards.isEmpty()) return

    var topCardIndex by remember { mutableIntStateOf(0) }
    val visibleCards = cards.subList(topCardIndex, minOf(topCardIndex + config.maxVisibleCards, cards.size))

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val maxWidth = constraints.maxWidth.toFloat()
        val maxHeight = constraints.maxHeight.toFloat()
        val swipeThresholdWidth = maxWidth * config.swipeThreshold
        val swipeThresholdHeight = maxHeight * config.swipeThreshold
        val density = LocalDensity.current

        // Render visible cards in reverse order so the top card is rendered last (on top)
        visibleCards.asReversed().forEachIndexed { reversedIndex, content ->
            val actualIndex = visibleCards.size - 1 - reversedIndex
            val isTopCard = actualIndex == 0

            if (isTopCard) {
                // Top card with gestures
                DraggableCard(
                    onSwiped = { direction ->
                        if (topCardIndex < cards.size) {
                            onSwipe(topCardIndex, direction)
                            topCardIndex++
                        }
                    },
                    swipeThresholdWidth = swipeThresholdWidth,
                    swipeThresholdHeight = swipeThresholdHeight,
                    rotationFactor = config.rotationFactor,
                    animationSpec = config.animationSpec,
                    initialOffset = Offset(x =reversedIndex * 10.0f, y = -reversedIndex * 10.0f)
                ) {
                    cardContent(content)
                }
            } else {
                // Background cards
                val scale = config.cardScale.pow(actualIndex)
                val yOffset = config.cardYOffset * actualIndex

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .offset(y = with(density) { yOffset.toDp() })
                        .scale(scale)
                ) {
                    cardContent(content)
                }
            }
        }
    }
}

@Composable
private fun DraggableCard(
    onSwiped: (SwipeDirection) -> Unit,
    swipeThresholdWidth: Float,
    swipeThresholdHeight: Float,
    rotationFactor: Float,
    animationSpec: androidx.compose.animation.core.AnimationSpec<Offset>,
    initialOffset: Offset,
    content: @Composable () -> Unit
) {
    val offset = remember { Animatable(initialOffset, Offset.VectorConverter) }
    var isSwiping by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(isSwiping) {
        if (!isSwiping) {
            offset.animateTo(Offset.Zero, animationSpec)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .offset {
                IntOffset(
                    offset.value.x.roundToInt(),
                    offset.value.y.roundToInt()
                )
            }
            .graphicsLayer {
                // Proportional rotation based on X offset
                rotationZ = offset.value.x * rotationFactor
                // Subtle scaling effect during swipe
                val scale = 1f - (abs(offset.value.x) / (swipeThresholdWidth * 5)).coerceIn(0f, 0.1f)
                scaleX = scale
                scaleY = scale
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = {
                        isSwiping = true
                    },
                    onDragEnd = {
                        isSwiping = false
                        coroutineScope.launch {
                            // Determine swipe direction if threshold is exceeded
                            val currentOffset = offset.value
                            when {
                                currentOffset.x > swipeThresholdWidth -> {
                                    // Animate to edge before removing
                                    offset.animateTo(Offset(size.width * 1.5f, currentOffset.y), animationSpec)
                                    onSwiped(SwipeDirection.RIGHT)
                                }
                                currentOffset.x < -swipeThresholdWidth -> {
                                    offset.animateTo(Offset(-size.width * 1.5f, currentOffset.y), animationSpec)
                                    onSwiped(SwipeDirection.LEFT)
                                }
                                currentOffset.y > swipeThresholdHeight -> {
                                    offset.animateTo(Offset(currentOffset.x, size.height * 1.5f), animationSpec)
                                    onSwiped(SwipeDirection.DOWN)
                                }
                                currentOffset.y < -swipeThresholdHeight -> {
                                    offset.animateTo(Offset(currentOffset.x, -size.height * 1.5f), animationSpec)
                                    onSwiped(SwipeDirection.UP)
                                }
                            }
                        }
                    },
                    onDragCancel = {
                        isSwiping = false
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        coroutineScope.launch {
                            offset.snapTo(offset.value + dragAmount)
                        }
                    }
                )
            }
    ) {
        content()
    }
}

// Helper extension function for power operations on Float
private fun Float.pow(exponent: Int): Float {
    var result = 1f
    repeat(exponent) {
        result *= this
    }
    return result
}