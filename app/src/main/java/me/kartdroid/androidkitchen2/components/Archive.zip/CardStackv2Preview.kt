package me.kartdroid.androidkitchen2.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp

@Composable
fun CardStackV2Example() {
    var remainingCards by remember { mutableStateOf(generateSampleCards()) }
    var lastSwipedDirection by remember { mutableStateOf<SwipeDirection?>(null) }

    Box(modifier = Modifier.fillMaxSize().padding(50.dp)) {
        CardStack(
            cards = remainingCards,
            onSwipe = { index, direction ->
                lastSwipedDirection = direction
                // Remove the card that was swiped
                remainingCards = remainingCards.filterIndexed { i, _ -> i != 0 }
                // Add a new card at the end if you want
                if (remainingCards.size < 5) {
                    remainingCards = remainingCards + listOf(
                        CardData(title = "New Card ${(Math.random() * 100).toInt()}",
                            color = getRandomColor())
                    )
                }
            },
            config = CardStackConfig(
                maxVisibleCards = 5,
                cardScale = 0.95f,
                cardYOffset = 100f,
                rotationFactor = 0.1f
            ),
            modifier = Modifier.padding(16.dp),
            cardContent = {
                SampleCard(text = it.title, color = it.color)
            }
        )

        // Display last swipe direction
        lastSwipedDirection?.let {
            Text(
                text = "Last swipe: $it",
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(16.dp),
                style = MaterialTheme.typography.subtitle1
            )
        }
    }
}

@Composable
fun SampleCard(text: String, color: Color) {
    Card(
        modifier = Modifier.fillMaxSize(),
        shape = RoundedCornerShape(16.dp),
        elevation = 8.dp
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(color),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = text,
                style = MaterialTheme.typography.h4,
                color = Color.White
            )
        }
    }
}

private fun generateSampleCards(): List<CardData> {
    val colors = listOf(
        Color(0xFFF44336), // Red
        Color(0xFF9C27B0), // Purple
        Color(0xFF2196F3), // Blue
        Color(0xFF4CAF50), // Green
        Color(0xFFFF9800)  // Orange
    )

    return List(10) { index ->
        CardData(
            title = "Card ${index + 1}",
            color = colors[index % colors.size]
        )
    }
}

private fun getRandomColor(): Color {
    return Color(
        red = (Math.random() * 0.7f + 0.3f).toFloat(),
        green = (Math.random() * 0.7f + 0.3f).toFloat(),
        blue = (Math.random() * 0.7f + 0.3f).toFloat()
    )
}

@Preview
@Composable
fun CardStackPreview() {
    MaterialTheme {
        CardStackV2Example()
    }
}