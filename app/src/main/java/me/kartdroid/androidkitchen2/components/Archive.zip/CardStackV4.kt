package me.kartdroid.androidkitchen2.components

import android.util.Log
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

// Direction enum to define swipe directions
enum class SwipeDirection {
    LEFT, RIGHT, UP, DOWN, NONE
}

// Function to track the result of a swipe
data class SwipeResult(
    val direction: SwipeDirection,
    val index: Int
)

@Composable
fun CardStack(
    modifier: Modifier = Modifier,
    items: List<Any>,
    thresholdConfig: (Float, Float) -> Float = { _, _ -> 0.2f },
    velocityThreshold: Float = 125f,
    onSwipe: (SwipeResult) -> Unit = {},
    cardContent: @Composable (Any, Int) -> Unit
) {
    if (items.isEmpty()) return

    // Remember the card indices
    val indices = remember { items.indices.toList() }
    val visibleCardCount = 3 // Number of cards visible in the stack

    // Size of the CardStack container
    var containerSize by remember { mutableStateOf(IntSize.Zero) }

    // Track current index
    var currentIndex by remember { mutableStateOf(0) }

    // Track drag state
    val dragOffset = remember { Animatable(Offset.Zero, Offset.VectorConverter) }

    // Coroutine scope for animations
    val coroutineScope = rememberCoroutineScope()

    // Calculate rotation based on drag offset
    val rotation by remember {
        derivedStateOf {
            if (containerSize.width > 0) {
                dragOffset.value.x * 15f / containerSize.width
            } else {
                0f
            }
        }
    }

    // Calculate if we've crossed the threshold for swipe
    val threshold by remember {
        derivedStateOf {
            if (containerSize.width > 0 && containerSize.height > 0) {
                thresholdConfig(containerSize.width.toFloat(), containerSize.height.toFloat())
            } else {
                0.0f
            }
        }
    }

    // Determine swipe direction
    val swipeDirection by remember {
        derivedStateOf {
            val offsetX = dragOffset.value.x
            val offsetY = dragOffset.value.y

            val xRatio = abs(offsetX) / (containerSize.width * threshold)
            val yRatio = abs(offsetY) / (containerSize.height * threshold)

            if (xRatio >= 1) {
                if (offsetX > 0) SwipeDirection.RIGHT else SwipeDirection.LEFT
            } else if (yRatio >= 1) {
                if (offsetY > 0) SwipeDirection.DOWN else SwipeDirection.UP
            } else {
                SwipeDirection.NONE
            }
        }
    }

    // Function to handle swipe
    val executeSwipe = { direction: SwipeDirection ->
        if (direction != SwipeDirection.NONE) {
            val targetIndex = currentIndex
            onSwipe(SwipeResult(direction, targetIndex))

            // Update current index after swipe
            currentIndex = (currentIndex + 1).coerceAtMost(items.size - 1)

            true
        } else false
    }

    // Function to handle card settling
    val settle = {
        coroutineScope.launch {
            val settlePoint = if (swipeDirection == SwipeDirection.NONE) {
                // Return to center if not past threshold
                Offset.Zero
            } else {
                // Continue swipe if past threshold
                val xMultiplier = when (swipeDirection) {
                    SwipeDirection.LEFT -> -2f
                    SwipeDirection.RIGHT -> 2f
                    else -> 0f
                }
                val yMultiplier = when (swipeDirection) {
                    SwipeDirection.UP -> -2f
                    SwipeDirection.DOWN -> 2f
                    else -> 0f
                }

                Offset(
                    x = xMultiplier * containerSize.width.toFloat(),
                    y = yMultiplier * containerSize.height.toFloat()
                )
            }

            dragOffset.animateTo(
                targetValue = settlePoint,
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
            ) {
                // If we've reached the target and it's not center, execute the swipe
                if (settlePoint != Offset.Zero && value.x.roundToInt() == settlePoint.x.roundToInt()
                    && value.y.roundToInt() == settlePoint.y.roundToInt()
                ) {
                    if (executeSwipe(swipeDirection)) {
                        coroutineScope.launch {
                            // Reset offset after successful swipe
                            dragOffset.snapTo(Offset.Zero)
                        }
                    }
                }
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged {
                containerSize = it
            }
    ) {
        // Display up to visibleCardCount cards
        indices.reversed().forEachIndexed { index, itemIndex ->
            val reverseIndex = indices.size - 1 - index

            // Only show if it's within the visible range
            if (reverseIndex >= currentIndex && reverseIndex < currentIndex + visibleCardCount) {
                val item = items[itemIndex]
                val visibleIndex = reverseIndex - currentIndex

                // Apply modifiers only to the top card
                val isTopCard = visibleIndex == 0
                val cardModifier = if (isTopCard) {
                    Modifier
                        .offset {
                            IntOffset(
                                dragOffset.value.x.roundToInt(),
                                dragOffset.value.y.roundToInt()
                            )
                        }
                        .graphicsLayer {
                            rotationZ = rotation
                        }
                        .pointerInput(currentIndex) {
                            detectDragGestures(
                                onDragStart = { _ ->
                                    // Optional: handle drag start
                                },
                                onDragEnd = {
                                    settle()
                                },
                                onDragCancel = {
                                    settle()
                                },
                                onDrag = { change, dragAmount ->
                                    coroutineScope.launch {
                                        dragOffset.snapTo(
                                            dragOffset.value + dragAmount
                                        )
                                    }
                                    change.consume()
                                }
                            )
                        }
                } else {
                    // Scale and opacity effect for cards behind the top card
                    val scale = 1f - (visibleIndex * 0.05f)
                    val yOffset = (visibleIndex * 20).toFloat()

                    Modifier.graphicsLayer {
                        scaleX = scale
                        scaleY = scale
                        translationY = yOffset
                    }
                }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .zIndex((items.size - visibleIndex).toFloat())
                        .then(cardModifier),
                    contentAlignment = Alignment.Center
                ) {
                    cardContent(item, itemIndex)
                }
            }
        }
    }

    // Handle programmatic swipe if needed
    LaunchedEffect(items) {
        // Reset when items change
        if (currentIndex >= items.size) {
            currentIndex = 0
        }
        dragOffset.snapTo(Offset.Zero)
    }
}

@Preview
@Composable
fun CardStackV4Example() {
    val cardItems = remember {
        listOf(
            "Card 1",
            "Card 2",
            "Card 3",
            "Card 4",
            "Card 5"
        )
    }

    CardStack(
        items = cardItems,
        thresholdConfig = { width, _ -> width * 0.2f },
        onSwipe = { result ->
            // Handle the swipe result
            Log.d("CardStack", "Swiped ${result.direction} on card ${result.index}")
        }
    ) { item, _ ->
        // Define how each card looks
        Card(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .fillMaxHeight(0.7f),
            elevation = 8.dp
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = item.toString(),
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}